<# Prompts for and stores vCenter credentials in a secure manner.
  The username is saved in cleartext. The password is saved as a SecureString.
  The output file is XML.
#>
function Set-vCenterCredentials ($OutputFile)
{
  $NewCredential = Get-Credential -Message @"
Enter the username and password for vCenter server '$Server'.
These credentials will be stored securely at '$OutputFile'."
"@
  if ($NewCredential -eq $null) {
    Write-Warning "No credentials were provided! Exiting."
    Exit 1
  }
  $export = "" | Select-Object Username, EncryptedPassword 
  $export.Username = $NewCredential.Username 
  $export.EncryptedPassword = $NewCredential.Password | ConvertFrom-SecureString 
  $export | Export-Clixml $OutputFile
  Write-Host -foregroundcolor green "Credentials saved to: $OutputFile"
  Return $NewCredential
}

<# Retrieves the securely stored vCenter credentials from a file on disk. #>
function Get-vCenterCredentials ($InputFile)
{
  $credentials = Import-Clixml $InputFile
  $import = "" | Select-Object Username, Password 
  $import.Username = $credentials.Username
  $import.Password = $credentials.EncryptedPassword | ConvertTo-SecureString
  Return $import
}

function Get-PowerCLICredentialUsername ($vCentercredfile)
{
  $credentials = Import-Clixml $vCentercredfile
  $username = $credentials.Username
  Return $username
}

function Get-PowerCLICredentialPassword ($vCentercredfile)
{
  $LoadedCredentials = Get-vCenterCredentials($vCentercredfile)
  $vCentercreds = New-Object System.Management.Automation.PsCredential($LoadedCredentials.Username, $LoadedCredentials.Password)
  $password = [PSCredential]::new(0, $vCentercreds.Password).GetNetworkCredential().Password
  Return $password
}

function Set-PowerCLICredential ($vCentercredfile)
{
  $LoadedCredentials = Get-vCenterCredentials($vCentercredfile)
  $vCentercreds = New-Object System.Management.Automation.PsCredential($LoadedCredentials.Username, $LoadedCredentials.Password)
  return $vCentercreds
}

#####################
# Log to both screen and file
function Write-Message {
  param (
    [Parameter(Mandatory=$false)]
    [AllowEmptyString()]
    [AllowNull()]
    [string]$Message = "",
    [Parameter(Mandatory=$false)]
    [ValidateSet("INFO", "INFONONEWLINE", "WARNING", "ERROR", "EULA", "PASS", "FAIL", "CHANGED", "SKIPPED", "SAFETY")]
    [string]$Level = "INFO"
  )
  
  $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
  if ($Level -eq "INFONONEWLINE") {
    $logEntry = "[$timestamp] [INFO] $Message"
  } else {
    $logEntry = "[$timestamp] [$Level] $Message"
  }

  # Output to screen
  switch ($Level) {
    "INFO"             { Write-Host $logEntry -ForegroundColor White }
    "INFONONEWLINE"    { Write-Host $logEntry -ForegroundColor White -NoNewline }
    "WARNING"          { Write-Host $logEntry -ForegroundColor DarkYellow }
    "ERROR"            { Write-Host $logEntry -ForegroundColor DarkRed }
    "EULA"             { Write-Host $logEntry -ForegroundColor Cyan }
    "PASS"             { Write-Host $logEntry -ForegroundColor Green }
    "FAIL"             { Write-Host $logEntry -ForegroundColor Red }
    "CHANGED"          { Write-Host $logEntry -ForegroundColor Yellow }
    "SKIPPED"          { Write-Host $logEntry -ForegroundColor Blue }
    "SAFETY"           { Write-Host $logEntry -ForegroundColor Green }
  }
}

Function Block-Script() {
  Write-Message "This script should not be run in a production environment. It will" -Level "ERROR"
  Write-Message "change things that can cause operational issues and/or require host" -Level "ERROR"
  Write-Message "restarts. If you accept the risk, please remove or comment the line:" -Level "ERROR"
  Write-Message " " -Level "ERROR"
  Write-Message "Block-Script" -Level "ERROR"
  Write-Message " " -Level "ERROR"
  Write-Message "in this script. By doing so, you accept any and all risk this script and" -Level "ERROR"
  Write-Message "these commands may pose to your environment." -Level "ERROR"
  Exit
}

Function Invoke-Pause() {
  Write-Message "Check the vSphere Client to make sure all tasks have completed, then press a key." -Level "INFO"
  $null = $host.UI.RawUI.FlushInputBuffer()
  while ($true) {
      $key = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
      if ($key.Character -match '[a-zA-Z0-9 ]') {
          break
      }
  }
}

#####################
# Check to see if we have the required version of PowerCLI. VMware.PowerCLI prior to 9.0 and VCF.PowerCLI post 9.0.
Function Test-PowerCLI() {
  param (
    [Parameter(Mandatory=$true)]
    [string]$MinimumPowerCLIVersion,
    [Parameter(Mandatory=$false)]
    [string]$ModuleName = "VCF.PowerCLI"
  )
  $installedVersion = (Get-Module -ListAvailable -All -Name $ModuleName).Version.ToString() | Sort-Object -Desc | Select-Object -First 1
  if ([System.Version]$MinimumPowerCLIVersion -gt [System.Version]$installedVersion) {
    Write-Message "This script requires PowerCLI $MinimumPowerCLIVersion or newer. Current version is $installedVersion" -Level "ERROR"
    Write-Message "Instructions for installation & upgrade can be found at https://developer.broadcom.com/powercli" -Level "ERROR"
    Write-Message "Some installations of PowerCLI cannot be detected. Use -NoSafetyChecks to skip this check." -Level "ERROR"
    Exit
  } else {
    Write-Message "This script requires PowerCLI $MinimumPowerCLIVersion or newer. Current version is $installedVersion." -Level "SAFETY"
  }
}

#####################
# Check to see if we are attached to a supported vCenter Server
Function Test-vCenter() {
  param (
    [Parameter(Mandatory=$true)]
    [string]$MinimumVCVersion,
    [Parameter(Mandatory=$true)]
    [string]$MaximumVCVersion
  )
  if ($global:DefaultVIServers.Count -lt 1) {
    Write-Message "No connected vCenters found." -Level "ERROR"
    Exit -1
  } elseif ($global:DefaultVIServers.Count -gt 1) {
    Write-Message "Multiple vCenter connections detected. Please disconnect any existing vCenter connections before running the script." -Level "ERROR"
    Exit -1
  } elseif ($global:DefaultVIServers.Count -eq 1) {
    $vcVersion = $global:DefaultVIServers.Version
    if (([System.Version]$vcVersion -lt [System.Version]$MinimumVCVersion) -or ([System.Version]$vcVersion -gt [System.Version]$MaximumVCVersion)) {
      Write-Message "Unsupported vCenter version: $($global:DefaultVIServers.Version) found on vCenter: $($global:DefaultVIServers.Name)" -Level "ERROR"
      Write-Message "Expecting vCenter version to be a minimum of $MinimumVCVersion and a maximum of $MaximumVCVersion." -Level "ERROR"
      Write-Message "Use -NoSafetyChecks to skip this check." -Level "ERROR"
      Exit -1
    } else {
      Write-Message "This script supports vCenter version $MinimumVCVersion to $MaximumVCVersion. Current version is $vcVersion." -Level "SAFETY"
    }
  }
}

#####################
# Check to see if we are attached to supported hosts. Older hosts might work but things change.
Function Test-ESX() {
  param (
    [Parameter(Mandatory=$true)]
    [VMware.VimAutomation.ViCore.Impl.V1.Inventory.VMHostImpl]$vmhost,
    [Parameter(Mandatory=$true)]
    [string]$MinimumESXVersion,
    [Parameter(Mandatory=$true)]
    [string]$MaximumESXVersion
  )
  if (([System.Version]$vmhost.Version -lt [System.Version]$MinimumESXVersion) -or ([System.Version]$vmhost.Version -gt [System.Version]$MaximumESXVersion)) {
    Write-Message "Unsupported ESX version: $($vmhost.Version) found on ESX Host: $($vmhost.Name)" -Level "ERROR"
    Write-Message "Expecting ESX version to be a minimum of $MinimumESXVersion and a maximum of $MaximumESXVersion." -Level "ERROR"
    Write-Message "Use -NoSafetyChecks to skip this check." -Level "ERROR"
    Exit -1
  } else {
    Write-Message "This script supports ESX version $MinimumESXVersion to $MaximumESXVersion. ESXi host: $($vmhost.Name) detected with version: $($vmhost.Version)." -Level "SAFETY"
  }
}

#####################
# Print header
Function Write-Header {
  param (
    [Parameter(Mandatory=$true)]
    [string]$Title,
    [Parameter(Mandatory=$true)]
    [string]$STIGVersion,
    [Parameter(Mandatory=$true)]
    [string]$name
  )
  $currentDateTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
  Write-Message "$Title - $STIGVersion" -Level "INFO"
  Write-Message "Use of this tool constitutes acceptance of the license and terms of use found at:" -Level "EULA"
  Write-Message "https://github.com/vmware/dod-compliance-and-automation" -Level "EULA"
  If($IsLinux){
    Write-Message "Remediation of $name started at $currentDateTime from $env:NAME by $env:USER" -Level "INFO"
  }Else{
    Write-Message "Remediation of $name started at $currentDateTime from $env:COMPUTERNAME by $env:USERNAME" -Level "INFO"
  }
}